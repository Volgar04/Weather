import 'package:flutter/material.dart';
import 'dart:async';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/services.dart';
//import 'package:location/location.dart';

void main() {
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);

  runApp(new MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      home: new MyHomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  State createState() => new MyHomePageState();
}

class MyHomePageState extends State<MyHomePage> with TickerProviderStateMixin {

  String _key = "cities";
  List<String> _cities = [];
  String _cityChosen;


  @override
  void initState() {
    super.initState();
    getPreferences();
  }

  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: new Text('Flutter'),
      ),
      drawer: new Drawer(
        child: new Container(
          color: Colors.blue,
          child: new ListView.builder(
              itemCount: _cities.length + 2,
              itemBuilder: (context, i){
                if (i==0){
                  return DrawerHeader(
                    child: new Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        textWithStyle("My Cities", fontSize: 22.0),
                        new RaisedButton(
                            color: Colors.white,
                            elevation: 8.0,
                            child: textWithStyle("Add city", color: Colors.blue),
                            onPressed: addCity
                        )
                      ],
                    ),
                  );
                } else if(i==1){
                  return new ListTile(
                    title: textWithStyle("My current city"),
                    onTap: (){
                      setState(() {
                        _cityChosen = null;
                        Navigator.pop(context);
                      });
                    },
                  );
                }else{
                  String city = _cities[i-2];
                  return new ListTile(
                    title: textWithStyle(city),
                    trailing: new IconButton(
                        icon: new Icon(Icons.delete, color: Colors.red,),
                        onPressed: (() => deletePreferences(city))
                    ),
                    onTap: () {
                      setState(() {
                        _cityChosen = city;
                        Navigator.pop(context);
                      });
                    },
                  );
                }
              }),
        ),
      ),
      body: new Center(
        child: new Text((_cityChosen == null)? "Current city ": _cityChosen),
      ),
    );
  }

  Text textWithStyle(String data, {color: Colors.white, fontSize: 18.0, fontStyle: FontStyle.italic, textAlign: TextAlign.center}){
    return new Text(
      data,
      textAlign: textAlign,
      style: new TextStyle(
          color: color,
          fontStyle: fontStyle,
          fontSize: fontSize
      ),
    );
  }

  Future<Null> addCity() async {
    return showDialog(
        barrierDismissible: true,
        builder: (BuildContext buildContext){
          return new SimpleDialog(
            contentPadding: EdgeInsets.all(20.0),
            title: textWithStyle("Add city", fontSize: 22.0, color: Colors.blue),
            children: <Widget>[
              new TextField(
                  decoration: new InputDecoration(
                      labelText: "City: "
                  ),
                  onSubmitted: (String str){
                    addPreferences(str);
                    Navigator.pop(context);
                  }
              )
            ],
          );
        },
        context: context
    );
  }

  void getPreferences() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    List<String> list = await sharedPreferences.getStringList(_key);
    if(list!=null){
      setState(() {
        _cities = list;
      });
    }
  }

  void addPreferences(String str) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    _cities.add(str);
    await sharedPreferences.setStringList(_key, _cities);
    getPreferences();
  }

  void deletePreferences(String str) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    _cities.remove(str);
    await sharedPreferences.setStringList(_key, _cities);
    getPreferences();
  }
}